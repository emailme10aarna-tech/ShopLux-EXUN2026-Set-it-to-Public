# ✦ LUXCART — React Native E-Commerce App

A fully-functional, production-ready e-commerce mobile app built with React Native (TypeScript).
Premium dark gold aesthetic. Runs on both iOS and Android.

---

## 📱 App Screens

| Screen | Description |
|---|---|
| **Landing** | Logo, tagline, Login & Register CTAs, animated orbs |
| **Login** | Email/password form, social login placeholders |
| **Register** | Full signup with password strength meter |
| **Home** | Product catalog, category filters, search, cart icon |
| **Product Detail** | Size/color picker, quantity, wishlist, add to cart |
| **Cart** | Item management, promo code, order summary, checkout |

---

## 🚀 Getting Started

### Prerequisites

- Node.js ≥ 18
- React Native CLI (NOT Expo)
- For iOS: macOS + Xcode 14+
- For Android: Android Studio + SDK 33+

### 1. Install dependencies

```bash
cd ShopLux
npm install
```

### 2. iOS Setup (macOS only)

```bash
cd ios
pod install
cd ..
npx react-native run-ios
```

### 3. Android Setup

Make sure an emulator is running or a device is connected.

```bash
npx react-native run-android
```

### 4. Start Metro bundler separately (optional)

```bash
npx react-native start
```

---

## 📁 Project Structure

```
ShopLux/
├── App.tsx                        # Root: navigation stack + types
├── src/
│   └── screens/
│       ├── LandingScreen.tsx      # ✦ Main landing page
│       ├── LoginScreen.tsx        # Sign in form
│       ├── RegisterScreen.tsx     # Create account form
│       ├── HomeScreen.tsx         # Product catalog
│       ├── ProductDetailScreen.tsx# Product page
│       └── CartScreen.tsx         # Shopping cart
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml
├── package.json
├── tsconfig.json
├── babel.config.js
└── metro.config.js
```

---

## 🎨 Design System

| Token | Value |
|---|---|
| Background | `#0A0A0F` |
| Surface | `#111118` |
| Border | `#1E1E2E` |
| Gold (primary) | `#C9A84C` |
| Gold (dark) | `#8B6914` |
| Text | `#FFFFFF` |
| Muted | `#888888` |

### Fonts
Uses system fonts with careful weight pairings (900 bold + 200 light) for the logo, monospace for labels.

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `@react-navigation/native` | Navigation container |
| `@react-navigation/native-stack` | Stack navigator |
| `react-native-screens` | Native screen optimization |
| `react-native-safe-area-context` | Safe area insets |

---

## ✅ Features

- [x] Animated landing page with pulsing gold orbs
- [x] Login with email/password validation
- [x] Register with password strength indicator
- [x] Product catalog with search + category filter
- [x] Product detail with size/color/quantity picker
- [x] Wishlist toggle with spring animation
- [x] Cart with qty controls + free shipping progress
- [x] Order summary with tax calculation
- [x] Full TypeScript types throughout
- [x] Consistent dark-gold design system

---

## 🧩 Extending the App

To add a real backend:
1. Replace `navigation.navigate('Home')` in Login/Register with actual API calls
2. Use `@react-native-async-storage/async-storage` for auth token storage
3. Swap hardcoded `PRODUCTS` array with a REST/GraphQL fetch

---

## 📄 License

MIT — free to use and modify for your coursework submission.
